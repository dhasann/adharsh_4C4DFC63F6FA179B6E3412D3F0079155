def linear_search_product(products, target):
    return [i for i, product in enumerate(products) if product == target]
